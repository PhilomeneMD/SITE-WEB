# The goal of this code
# 1. create a route that enable to access to the page 
# 2. accessing the database in flask 
# 3. tryin to demo the data in html 

from flask import Flask, render_template
import psycopg2
import pandas as pd

app = Flask(__name__)

@app.route('/hello')
def hello():
    return 'hello,wolrd!'

@app.route('/')
def home():
    return render_template('index.html')


# accessing the database, and trying to get the items in html 

# --- Database connection settings --- 
DB_CONFIG = {
    "host": "localhost",
    "database": "your database name",
    "user": "postgres",
    "password": "yourpasswords",
    "port": 5432  # default PostgreSQL port
}

@app.route('/data_description')
def show_data():
    # Connect to PostgreSQL
    conn = psycopg2.connect(**DB_CONFIG)

    # Query the first 5 rows
    query = "SELECT * FROM animal LIMIT 5;"
    df = pd.read_sql(query, conn)

    # Close the connection
    conn.close()

    # Convert dataframe to list of dicts (easy to render in HTML)
    animals = df.to_dict(orient='records')

    # Pass to template
    return render_template('data_description.html', animals=animals, columns=df.columns)



if __name__ == '__main__':
    app.run(debug=True)